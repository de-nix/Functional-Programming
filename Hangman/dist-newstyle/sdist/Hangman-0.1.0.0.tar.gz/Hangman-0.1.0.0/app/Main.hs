module Main where
import Control.Monad (forever) 
import Data.Char (toLower) 
import Data.Maybe (isJust) -- [3]
import Data.List (intersperse) -- [4]
import System.Exit (exitSuccess) 
import System.IO 
    (BufferMode(NoBuffering),
    hSetBuffering,
    stdout)
 
import Lib
main :: IO ()
main = putStrLn "(0,5)"
