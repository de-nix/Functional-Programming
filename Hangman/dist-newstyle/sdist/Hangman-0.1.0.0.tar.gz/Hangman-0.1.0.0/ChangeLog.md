# Changelog for Hangman

## Unreleased changes
